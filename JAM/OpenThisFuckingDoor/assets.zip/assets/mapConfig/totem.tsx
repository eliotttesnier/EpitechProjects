<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="totem" tilewidth="100" tileheight="100" spacing="10" margin="10" tilecount="1" columns="1">
 <image source="../totem.png" width="160" height="160"/>
</tileset>
